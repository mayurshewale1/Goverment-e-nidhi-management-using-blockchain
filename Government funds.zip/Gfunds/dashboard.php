<?php
include('connection.php');
    if(isset($_POST['submit']))
    {
        $price=$_POST['price'];

        $money=$_POST['money'];
       
        

$sql="Insert into money(price,money)values('".$price."','".$money."')";
        $res=mysqli_query($con,$sql);
      header("Location:display.php");

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<style> 
body {
 margin-top:200px;
}
body {
  background-image: url('R1.png');
}
.head{
  width:800px;
  background: #fff;
  border-radius: 0px;
  overflow: hidden;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  flex-wrap: wrap;
  padding:  10px 10px 10px 10px;
}
  </style>
    <title>Document</title>
</head>

<body>
  
    
<div class=" container col-lg-4 m-auto">       
    <form method="post">
    <h3 class="text-center">Send Money</h3>
    <div class="card">
        <div class="head col-lg-12 "><br>
        <div class="col-lg-12">
            <label for=""><b>Price</b></label>
            <input type="text" name="price" class="form-control">
        </div>
        <div class="col-lg-12">
        <label> <b>User</b> </label>  
            <select class="form-control" name="money">  
            <option value = "1"> 1   
            </option>  
            <option value = "2"> 2   
            </option>  
            <option value = "3"> 3  
            </option>  
            <option value = "4"> 4  
            </option>  
            </select>  
        </div>
             <div class="row  col-lg-12 mt-2">
                        &nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary" name="submit">Submit</button>
                         </div>
            </div>
            </div>


            
                   
        </div><br>

    </form>
</div>
        </div>


   
</body>
</html>